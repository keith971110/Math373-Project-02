import numpy as np
import time
import pandas as pd
import random
import matplotlib.pyplot as plt

def LoadData(file):
    
    # record loading time
    start = time.time()
    print('start loading')

    Alldata = pd.read_csv(file)
    # np.mat() transfer to matrix format
    data = np.mat(Alldata.iloc[:,1:].values)
    
    label = []
    temp = Alldata['label']
    for num in temp:
        if num >= 5:
            label.append(1)
        else:
            label.append(-1)
    
    label = np.mat(label).T
    
    print('end loading')
    end = time.time()
    print('loading time: ' , end - start)

    return data, label

def Perceptron(train_data, train_label, itertime):
    start = time.time()
    print('start training')
    
    sampleNum, featureNum = np.shape(train_data)
    
    w = np.zeros(featureNum)
    b = 0
    h = 0.0001
    
    for t in range(itertime):
        
        # Use while loop for the SGD
        a = 0
        while a == 0:
            i = random.sample(range(0,sampleNum - 1), 1)[0]

            xi = train_data[i]
            yi = train_label[i]
            
            # Check whether the sample point is a misclassification point
            if -1 * yi * (w * xi.T + b) >= 0:
                
                wG = -1 * yi * xi
                bG = -1 * yi
            
                w = w + h * -1 * wG
                b = b + h * -1 * bG

                a = 1
    
    print('end training')
    end = time.time()
    print('training time: ', end - start)

    return w, b



def classifier(test_data, test_label, w, b):

    start = time.time()
    print('start testing')
    
    testNum = len(test_label)
    
    errorCnt = 0
    
    # Iterate through the instances in the test set and classify them
    for n in range(testNum):
        
        xi = test_data[n]
        yi = test_label[n]
        
        if yi * (w * xi.T + b) < 0:
            errorCnt += 1
    
    Accurate = 1 - (errorCnt / testNum)
    
    print('end testing')
    print('Accurate: ', Accurate)
    end = time.time()
    print('training time: ', end - start)

    return Accurate



# Test the whole program
if __name__ ==  '__main__':
    
    train_data, train_label = LoadData('mnist_train.csv')

    itertime = 1200
    w, b = Perceptron(train_data, train_label, itertime)
    
    test_data, test_label = LoadData('mnist_test.csv')
    
    accurate = classifier(test_data, test_label, w, b)


if __name__ ==  '__main__':
    
    train_data, train_label = LoadData('mnist_train.csv')
    
    test_data, test_label = LoadData('mnist_test.csv')
    
    itertime_group = np.linspace(100,2000,40)

    accurate_group = []
    
    # train each itertime
    for itertime in itertime_group:
        itertime = int(itertime)
        w, b = Perceptron(train_data, train_label, itertime)
  
        accurate = classifier(test_data, test_label, w, b)
        accurate_group.append(accurate)
    
    plt.plot(itertime_group, accurate_group)
    plt.xlabel('itertime')
    plt.ylabel('accurate')
    plt.show()