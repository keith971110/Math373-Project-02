from sklearn import datasets
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.lines as mlines

# Load data
iris = datasets.load_iris()
X=iris.data[0:99,:2]
y=iris.target[0:99]
# Plot the training points
x_min, x_max = X[:, 0].min() - .5, X[:, 0].max() + .5
y_min, y_max = X[:, 1].min() - .5, X[:, 1].max() + .5
plt.figure(2, figsize=(8, 6))
plt.clf()
plt.scatter(X[:, 0], X[:, 1], c=y, cmap=plt.cm.Set1,edgecolor='k')
plt.xlabel('length')
plt.ylabel('width')
plt.xlim(x_min, x_max)
plt.ylim(y_min, y_max)
plt.show()

def gd(theta, y_hat, X_T, dist, cost, lr):
	start = time()
	global X, Y, margin, m, indices
	cost_log = []
	epoch = 0
	
	while cost > margin:
		cost_log.append(cost)
		#cost_log.append(cost) #commented for timing
		epoch += 1
		grad = np.matmul(X_T, dist)/-m
		theta = theta-lr*grad

		y_hat = np.matmul(X, theta)
		dist = Y-y_hat
		X_T = X.T
		cost = MSE(dist)
	cost_log.append(cost)
	end = time()
	print("\n" + "Finished GD in " + str(epoch+1), "epochs with error " + str(cost_log[-1]) + "\n")
	print("Optimal theta:", theta)

	print("\n\n" + "y_hat, y")
	for i in indices:
		print(y_hat[i], Y[i])

	return end-start, cost_log

# Plot linear classification
fig, ax = plt.subplots()
ax.scatter(X[:, 0], X[:, 1], c=y, cmap=plt.cm.Set1,edgecolor='k')
line_B_GD=mlines.Line2D([0,7],[-0.5527,4.1577],color='red')
line_Mini_GD=mlines.Line2D([0,7],[-0.56185,4.1674],color='blue')
line_Sto_GD=mlines.Line2D([0,7],[-0.5488,4.1828],color='green')
ax.add_line(line_B_GD)
ax.add_line(line_Mini_GD)
ax.add_line(line_Sto_GD)
ax.set_xlabel('Sepal length')
plt.show()

